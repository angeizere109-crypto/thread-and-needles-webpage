document.addEventListener('DOMContentLoaded', () => {
  const makersTable = document.getElementById('makersTable');
  const makers = ['Amara Nkosi', 'Lebo Mokoena', 'Zanele Dlamini', 'Mia van der Merwe', 'Thando Khumalo', 'Naledi Molefe', 'Sibongile Ndlovu', 'Aisha Patel', 'Kea Ramokgopa', 'Lerato Sithole', 'Emma Jacobs', 'Palesa Maseko', 'Nandi Cele', 'Kiara Naidoo', 'Boitumelo Dube', 'Rethabile Mokoena', 'Samkelo Zulu', 'Lindiwe Khoza', 'Yasmin Khan', 'Refilwe Mothiba', 'Ayanda Mthembu', 'Charlotte Botha', 'Karabo Mokoena', 'Nomsa Mkhize', 'Tumi Radebe', 'Zinhle Mthethwa', 'Farah Ismail', 'Mpho Mokoena', 'Koketso Moloi', 'Busi Ngcobo', 'Julia Smith', 'Lerato Ndlovu', 'Sanele Dlamini', 'Masego Seabi', 'Thuli Mthembu', 'Anathi Gqirana', 'Miriam Pillay', 'Mbalenhle Mthethwa', 'Lesego Modise', 'Noxolo Gumede', 'Anele Mbatha', 'Sasha Meyer', 'Itumeleng Moagi', 'Zandile Nene', 'Sbahle Mkhize', 'Rorisang Mokwena', 'Kagiso Pooe', 'Akhona Tyali', 'Masechaba Tau', 'Nokuthula Sithole', 'Lihle Mkhize', 'Zoya Esack', 'Tshegofatso Mokone', 'Mpumi Dube', 'Reneilwe Mogale', 'Keneilwe Ramathe', 'Chantel Daniels', 'Luyanda Maseko', 'Musa Nxumalo', 'Pinky Mokoena'];
  const courses = ['The First Stitch', 'Cut & Create', 'Your Own Label'];
  const skills = ['Garment construction', 'Pattern drafting', 'Sustainable design', 'Machine sewing', 'Draping', 'Hand finishing', 'Fashion illustration', 'Collection planning'];
  const cities = ['Johannesburg', 'Pretoria', 'Durban', 'Cape Town', 'Soweto', 'Midrand'];

  if (makersTable && window.jQuery && jQuery.fn.DataTable) {
    jQuery(makersTable).DataTable({
      data: makers.map((name, i) => [name, courses[i % 3], String(2023 + i % 3), skills[i % skills.length], cities[i % cities.length]]),
      columns: [{ title: 'NAME' }, { title: 'COURSE' }, { title: 'GRADUATED' }, { title: 'FAVOURITE SKILL' }, { title: 'LOCATION' }],
      pageLength: 10,
      lengthMenu: [10, 25, 50],
      order: [[0, 'asc']],
      language: {
        search: 'Search makers:',
        lengthMenu: 'Show _MENU_ makers',
        info: 'Showing _START_–_END_ of _TOTAL_ makers',
        zeroRecords: 'No matching makers',
        paginate: { previous: '‹', next: '›' }
      },
      dom: '<"directory-toolbar mb-3"lf>t<"directory-footer row g-3 align-items-center mt-3"<"col-md-6"i><"col-md-6 d-flex justify-content-md-end"p>>'
    });
  }

  document.querySelectorAll('.mobile-menu a').forEach(link => {
    link.addEventListener('click', event => {
      const href = link.getAttribute('href');
      if (!href || href.startsWith('#')) return;

      event.preventDefault();

      const offcanvasEl = document.getElementById('mobileMenu');
      if (offcanvasEl && window.bootstrap && bootstrap.Offcanvas) {
        const instance = bootstrap.Offcanvas.getInstance(offcanvasEl);
        if (instance) instance.hide();
      }

      window.location.assign(href);
    });
  });

  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => new bootstrap.Tooltip(el));
  document.querySelectorAll('[data-bs-toggle="popover"]').forEach(el => new bootstrap.Popover(el));

  const encouragement = document.getElementById('encourageToast');
  const toastTrigger = document.getElementById('toastTrigger');
  if (encouragement && toastTrigger) {
    toastTrigger.addEventListener('click', () => bootstrap.Toast.getOrCreateInstance(encouragement).show());
  }

  const courseModal = document.getElementById('courseModal');
  const courseInterested = document.getElementById('courseInterested');
  let selectedCourse = 'The First Stitch';
  const courseLabels = {
    'The First Stitch': 'The First Stitch — Sewing Foundations',
    'Cut & Create': 'Cut & Create — Pattern Making',
    'Your Own Label': 'Your Own Label — Fashion Business'
  };

  if (courseModal) {
    courseModal.addEventListener('show.bs.modal', event => {
      selectedCourse = event.relatedTarget?.dataset.course || 'The First Stitch';
      document.getElementById('courseModalTitle').textContent = selectedCourse;
      if (courseInterested) {
        courseInterested.href = `apply.html?course=${encodeURIComponent(courseLabels[selectedCourse] || selectedCourse)}`;
      }
    });
  }

  const galleryModal = document.getElementById('galleryModal');
  if (galleryModal) {
    galleryModal.addEventListener('show.bs.modal', event => {
      const opener = event.relatedTarget;
      const preview = document.getElementById('galleryPreview');
      preview.src = opener.dataset.gallerySrc;
      preview.alt = opener.dataset.galleryTitle;
      document.getElementById('galleryModalTitle').textContent = opener.dataset.galleryTitle;
      document.getElementById('galleryModalCopy').textContent = opener.dataset.galleryCopy;
    });
  }

  const courseSelect = document.getElementById('course');
  const requestedCourse = new URLSearchParams(window.location.search).get('course');
  if (courseSelect && requestedCourse) {
    const option = [...courseSelect.options].find(item => item.textContent.startsWith(requestedCourse));
    if (option) courseSelect.value = option.value;
  }

  const form = document.getElementById('applicationForm');
  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      event.stopPropagation();
      form.classList.add('was-validated');
      if (!form.checkValidity()) return;

      const values = Object.fromEntries(new FormData(form).entries());
      const applications = JSON.parse(localStorage.getItem('threadNeedleApplications') || '[]');
      applications.push({ ...values, savedAt: new Date().toISOString() });
      localStorage.setItem('threadNeedleApplications', JSON.stringify(applications));
      document.getElementById('formMessage').textContent = `Thank you, ${values.firstName}! Your application is saved on this device.`;
      form.reset();
      form.classList.remove('was-validated');
    });
  }
});
